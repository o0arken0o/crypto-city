@echo off
setlocal
title Apri Crypto City
echo Crypto City: avvio dell'aggiornamento e apertura della citta'.
echo Se il progetto e' sul Desktop verra' cercato automaticamente.
echo.
where py >nul 2>nul
if errorlevel 1 goto python
py -3 --version >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0install_city.py" --launch %*
goto result
:python
where python >nul 2>nul
if errorlevel 1 goto missing
python --version >nul 2>nul
if errorlevel 1 goto missing
python "%~dp0install_city.py" --launch %*
goto result
:missing
echo Python non trovato. Serve Python 3.10 o successivo, consigliato 3.12.
echo Installa Python da python.org scegliendo Add Python to PATH, poi riprova.
pause
exit /b 1
:result
set "city_result=%errorlevel%"
echo.
if not "%city_result%"=="0" echo Apertura non completata. Leggi l'errore sopra.
if "%city_result%"=="0" echo Il browser e' pronto. Lascia aperta la finestra del server.
pause
exit /b %city_result%
