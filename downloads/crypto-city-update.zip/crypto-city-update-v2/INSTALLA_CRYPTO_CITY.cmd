@echo off
setlocal
title Installa Crypto City
where py >nul 2>nul
if errorlevel 1 goto python
py -3 --version >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0install_city.py" %*
goto result
:python
where python >nul 2>nul
if errorlevel 1 goto missing
python --version >nul 2>nul
if errorlevel 1 goto missing
python "%~dp0install_city.py" %*
goto result
:missing
echo Python non trovato. Installa Python 3.12 da python.org, poi riprova.
echo Durante l'installazione scegli Add Python to PATH.
pause
exit /b 1
:result
set "city_result=%errorlevel%"
echo.
if not "%city_result%"=="0" echo Installazione non completata. Leggi l'errore sopra.
pause
exit /b %city_result%
