#!/usr/bin/env python3
"""Install only the Crypto City HTML; optionally start the existing local server.

No Git operations, dependency installation or external network requests are used.
"""
import argparse
import datetime
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import webbrowser
from html.parser import HTMLParser


PACKAGE = Path(__file__).resolve().parent
PAYLOAD = PACKAGE / "dashboard" / "index.html"
LOCAL_CONFIG = PACKAGE / ".crypto-city-local.json"
ROOMS = {"btc", "eth", "sol", "xrp", "ada", "cro", "scanner", "quant", "risk", "portfolio", "yield", "chief"}
HOST = "127.0.0.1"
PORT = 8877


class CityError(Exception):
    pass


class CityHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.model = False
        self.rooms = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "script" and attrs.get("id") == "city-model":
            self.model = True
        if tag == "a" and attrs.get("data-city-room"):
            room = attrs["data-city-room"]
            if attrs.get("href") == "#city/" + room:
                self.rooms.append(room)


def valid_city(html):
    parser = CityHTML()
    parser.feed(html.decode("utf-8"))
    return parser.model and len(parser.rooms) == 12 and set(parser.rooms) == ROOMS


def validate_repo(repo):
    repo = Path(repo).expanduser().resolve()
    required = (
        "dashboard/server.py", "dashboard/index.html",
        "dashboard/vendor/three/three.module.min.js",
        "dashboard/vendor/three/addons/controls/OrbitControls.js", "engine/mm.py",
    )
    missing = [name for name in required if not (repo / name).is_file()]
    if missing:
        raise CityError("File necessari mancanti in " + str(repo) + ":\n  " + "\n  ".join(missing)
                        + "\nAggiornamento interrotto; nessun file modificato.")
    dashboard = repo / "dashboard"
    if dashboard.is_symlink() or (dashboard / "index.html").is_symlink():
        raise CityError("dashboard o index.html e' un collegamento: scegli il checkout reale.")
    server = (dashboard / "server.py").read_text(encoding="utf-8")
    for route in ("/plancia", "/api/state", "/vendor/three/"):
        if route not in server:
            raise CityError("Il server locale non dichiara la route " + route
                            + ". Questa versione non e' compatibile: nessun file modificato.")
    three = (dashboard / "vendor/three/three.module.min.js").read_text(encoding="utf-8")
    if not re.search(r'\bconst\s+\w+\s*=\s*[\"\']170[\"\']', three):
        raise CityError("Three.js locale non e' r170, la versione verificata per questo pacchetto."
                        + "\nLe librerie esistenti restano intatte; nessun file modificato.")
    return repo


def remembered_repo():
    """Ignore stale or malformed local metadata without disclosing its contents."""
    try:
        if LOCAL_CONFIG.is_symlink() or not LOCAL_CONFIG.is_file():
            return None
        if LOCAL_CONFIG.samefile(PAYLOAD) or LOCAL_CONFIG.stat().st_size > 32768:
            return None
        config = json.loads(LOCAL_CONFIG.read_text(encoding="utf-8"))
        if not isinstance(config, dict) or config.get("version") != 1:
            return None
        path = config.get("repo")
        if not isinstance(path, str) or not path or "\x00" in path:
            return None
        return validate_repo(path)
    except (CityError, OSError, UnicodeError, ValueError):
        return None


def remember_repo(repo):
    """Save only the successful installation's path, alongside this package."""
    temporary = None
    try:
        def check_target():
            if LOCAL_CONFIG.is_symlink():
                raise OSError("Configurazione locale collegata")
            if LOCAL_CONFIG.exists():
                if not LOCAL_CONFIG.is_file() or LOCAL_CONFIG.samefile(PAYLOAD):
                    raise OSError("Configurazione locale non utilizzabile")

        check_target()
        metadata = json.dumps({"version": 1, "repo": str(repo)}, ensure_ascii=False) + "\n"
        with tempfile.NamedTemporaryFile(dir=PACKAGE, prefix=".crypto-city-config-", suffix=".tmp",
                                         mode="w", encoding="utf-8", delete=False) as file:
            temporary = Path(file.name)
            file.write(metadata)
            file.flush()
            os.fsync(file.fileno())
        check_target()
        os.replace(temporary, LOCAL_CONFIG)
        temporary = None
    except (OSError, UnicodeError):
        print("Installazione riuscita. Non posso ricordare la cartella in questo pacchetto;"
              " il launcher chiedera' di sceglierla di nuovo.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass


def choose_repo():
    print("Scegli la cartella Crypto Machine che contiene dashboard, engine e state.", flush=True)
    if os.name == "nt":
        root = None
        try:
            import tkinter
            from tkinter import filedialog
        except ImportError:
            tkinter = None
        if tkinter is not None:
            try:
                root = tkinter.Tk()
                root.withdraw()
                root.attributes("-topmost", True)
                desktop = Path.home() / "Desktop"
                initial = desktop if desktop.is_dir() else Path.home()
                entered = filedialog.askdirectory(
                    parent=root,
                    title="Crypto Machine: scegli la cartella con dashboard, engine e state",
                    initialdir=str(initial), mustexist=True,
                )
            except tkinter.TclError:
                pass
            else:
                if not entered:
                    raise CityError("Selezione annullata; nessun file modificato.")
                return validate_repo(entered)
            finally:
                if root is not None:
                    try:
                        root.destroy()
                    except tkinter.TclError:
                        pass
        print("Selettore cartelle non disponibile: incolla il percorso nella finestra.")
    print("In Esplora file: clic destro sul percorso > Copia indirizzo come testo.")
    print("Incolla il percorso che inizia con C:\\, non l'indirizzo http del browser.")
    try:
        entered = input("Percorso cartella (puoi incollarlo qui): ").strip().strip('"')
    except EOFError:
        raise CityError("Percorso assente. Usa: python install_city.py \"C:\\percorso\\crypto-machine\"") from None
    if not entered:
        raise CityError("Nessuna cartella selezionata; nessun file modificato.")
    return validate_repo(entered)


def find_repo(explicit=None):
    if explicit:
        return validate_repo(explicit)
    saved = remembered_repo()
    if saved is not None:
        print("Uso la cartella Crypto Machine dell'installazione precedente: " + str(saved))
        return saved
    candidates = []
    for start in (Path.cwd(), PACKAGE):
        for parent in (start, *start.parents):
            for candidate in (parent, parent / "crypto-machine"):
                if (candidate / "dashboard/server.py").is_file():
                    candidate = candidate.resolve()
                    if candidate not in candidates:
                        candidates.append(candidate)
        if candidates and start == Path.cwd():
            break
    if len(candidates) == 1:
        print("Cartella Crypto Machine: " + str(candidates[0]))
        return validate_repo(candidates[0])
    if candidates:
        print("Trovate piu' cartelle; scegli quella che usi sul computer:")
        for candidate in candidates:
            print("  " + str(candidate))
    return choose_repo()


def install(repo):
    repo = validate_repo(repo)
    if not PAYLOAD.is_file():
        raise CityError("Manca dashboard/index.html nel pacchetto: estrai tutto lo ZIP prima di avviare.")
    source = PAYLOAD.read_bytes()
    if not valid_city(source):
        raise CityError("Il file nel pacchetto non contiene Crypto City e le 12 sale; installazione interrotta.")
    target = repo / "dashboard/index.html"
    original = target.read_bytes()
    if original == source:
        print("Crypto City e' gia' installata; nessun file riscritto.")
        remember_repo(repo)
        return None
    backups = target.parent / ".crypto-city-backups"
    if backups.is_symlink():
        raise CityError("La cartella backup e' un collegamento; installazione interrotta.")
    backups.mkdir(exist_ok=True)
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    backup = backups / ("index-" + timestamp + "-" + hashlib.sha256(original).hexdigest()[:8] + ".html")
    with backup.open("xb") as file:
        file.write(original)
        file.flush()
        os.fsync(file.fileno())
    shutil.copystat(target, backup)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".crypto-city-", suffix=".tmp", delete=False) as file:
            temporary = Path(file.name)
            file.write(source)
            file.flush()
            os.fsync(file.fileno())
        os.chmod(temporary, target.stat().st_mode)
        if target.read_bytes() != original:
            raise CityError("index.html e' cambiato durante l'installazione; file attuale conservato.")
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    print("Crypto City installata: " + str(target))
    print("Backup della pagina precedente: " + str(backup))
    print("Modificata solo l'interfaccia dashboard/index.html.")
    print("Per aprirla, avvia AVVIA_CRYPTO_CITY.cmd e lascia aperta la finestra del server.")
    remember_repo(repo)
    return backup


def http_get(base, path, limit=2 * 1024 * 1024):
    # Loopback requests bypass any inherited external proxy. No credentials are read.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(base + path, headers={"Cache-Control": "no-cache"})
    try:
        with opener.open(request, timeout=2) as response:
            data = response.read(limit + 1)
            if len(data) > limit:
                raise CityError("Risposta locale troppo grande: " + path)
            return response.status, response.headers.get("Content-Type", ""), data
    except urllib.error.HTTPError as error:
        return error.code, error.headers.get("Content-Type", ""), b""


def verify_running_server(base, expected_html):
    status, _, data = http_get(base, "/healthz", limit=4096)
    try:
        healthy = json.loads(data).get("ok") is True
    except (ValueError, AttributeError):
        healthy = False
    if status != 200 or not healthy:
        raise CityError("La porta risponde, ma /healthz non identifica il server Crypto Machine.")
    status, content_type, data = http_get(base, "/plancia")
    if status != 200 or "text/html" not in content_type or not valid_city(data):
        raise CityError("La porta risponde, ma /plancia non contiene Crypto City e tutte le 12 sale.")
    if data != expected_html:
        raise CityError("La porta risponde con una versione diversa della plancia."
                        + "\nChiudi manualmente quel server oppure usa la sua cartella corretta.")
    status, _, data = http_get(base, "/api/state")
    if status == 401:
        print("Il server richiede il token della plancia: inseriscilo solo nel browser, se richiesto.")
        return
    try:
        state_ok = isinstance(json.loads(data).get("state"), dict)
    except (ValueError, AttributeError):
        state_ok = False
    if status != 200 or not state_ok:
        raise CityError("Crypto City e' presente, ma /api/state non fornisce i dati (HTTP " + str(status)
                        + "). Controlla l'errore nella finestra del server.")


def port_occupied(port):
    try:
        # A short TCP connect to a closed port can time out on Windows.
        # Check the local bind instead, without contacting another process.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            elif os.name != "nt":
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind((HOST, port))
        return False
    except OSError as error:
        if error.errno == errno.EADDRINUSE or getattr(error, "winerror", None) == 10048:
            return True
        raise CityError("Impossibile verificare la porta locale " + str(port) + ": " + str(error)) from None


def launch(repo, port=PORT, open_browser=True, startup_timeout=25):
    repo = validate_repo(repo)
    expected_html = (repo / "dashboard/index.html").read_bytes()
    if not valid_city(expected_html):
        raise CityError("Questa cartella non contiene ancora Crypto City. Avvia prima INSTALLA_CRYPTO_CITY.cmd.")
    base = "http://" + HOST + ":" + str(port)
    process = None
    if port_occupied(port):
        try:
            verify_running_server(base, expected_html)
        except (CityError, urllib.error.URLError, UnicodeError, OSError) as error:
            raise CityError("La porta " + str(port) + " e' gia' occupata. " + str(error)
                            + "\nNessun processo e' stato chiuso e nessun secondo server e' stato avviato.") from None
        print("Crypto City e' gia' attiva su " + base + ". Apro quella istanza.")
    else:
        env = os.environ.copy()
        env.update(MM_HOST=HOST, MM_PORT=str(port), MM_AUTOSTART="false")
        flags = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
        process = subprocess.Popen([sys.executable, str(repo / "dashboard/server.py")],
                                   cwd=repo, env=env, creationflags=flags)
        print("Avvio del server locale sulla porta " + str(port) + "; attendo la pagina...", flush=True)
        deadline = time.monotonic() + startup_timeout
        last_error = "server non ancora pronto"
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise CityError("Il server si e' fermato (codice " + str(process.returncode)
                                + "). Leggi l'errore nella sua finestra.")
            try:
                verify_running_server(base, expected_html)
                break
            except (CityError, urllib.error.URLError, UnicodeError, OSError) as error:
                last_error = str(error)
                time.sleep(.2)
        else:
            raise CityError("Il server non e' pronto: " + last_error
                            + "\nLa finestra del server resta aperta per leggere l'errore.")
        print("Server e interfaccia verificati. Lascia aperta la finestra del server.")
    url = base + "/plancia#city"
    print("Apri: " + url)
    if open_browser and not webbrowser.open(url, new=2):
        print("Non riesco ad aprire il browser automaticamente: copia l'indirizzo qui sopra.")
    return process


def main(argv=None):
    if sys.version_info < (3, 10):
        print("Serve Python 3.10 o successivo; consigliato Python 3.12.", file=sys.stderr)
        return 1
    parser = argparse.ArgumentParser(description="Aggiorna solo l'interfaccia locale di Crypto Machine.")
    parser.add_argument("repo", nargs="?", help="Cartella del repository Crypto Machine")
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument("--launch-only", action="store_true", help="Apri la citta' gia' installata")
    actions.add_argument("--launch", action="store_true", help="Installa, poi apri la citta'")
    args = parser.parse_args(argv)
    try:
        repo = find_repo(args.repo)
        if not args.launch_only:
            install(repo)
        if args.launch or args.launch_only:
            launch(repo)
    except (CityError, OSError, UnicodeError) as error:
        print("ERRORE: " + str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Operazione interrotta.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
