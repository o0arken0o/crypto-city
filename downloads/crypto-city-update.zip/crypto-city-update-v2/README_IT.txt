CRYPTO CITY - AGGIORNAMENTO DELL'INTERFACCIA LOCALE

La nuova interfaccia preparata nell'ambiente cloud non aggiorna da sola i file
sul tuo computer. Questo pacchetto trasferisce la pagina Crypto City nel tuo
repository locale, conservando una copia della pagina precedente.

1. Estrai tutto lo ZIP (non avviare i file direttamente dentro lo ZIP).
2. Apri INSTALLA_CRYPTO_CITY.cmd con doppio clic.
   Su Windows, se la cartella non e' rilevata, si apre un selettore: scegli
   la tua cartella crypto-machine, quella che contiene le sottocartelle
   dashboard, engine e state. Non scegliere la cartella crypto-city-update.
   Se il selettore non e' disponibile, in Esplora file fai clic destro sul
   percorso in alto e scegli "Copia indirizzo come testo". Incollalo nella
   finestra nera: deve essere un percorso locale, non un indirizzo http.
3. Apri AVVIA_CRYPTO_CITY.cmd con doppio clic. Il launcher ricorda la cartella
   dopo l'installazione riuscita. Se non e' piu' valida, te la fa scegliere
   nuovamente. Lascia aperta la finestra del server che compare.
4. Il browser si apre su http://127.0.0.1:8877/plancia#city.
   Dovresti vedere Crypto City e i 12 edifici/sale cliccabili.

Usa questo indirizzo completo: /office.html e' la sala trading precedente,
mentre /plancia#city e' la nuova home. La porta 8877 distingue il nuovo avvio
dalla pagina precedente sulla porta 8787 e dalla sua cache. Se il browser
chiede il token della plancia, inserisci il tuo token esistente nel browser.

REQUISITI
Python 3.10 o successivo (verificato con 3.12) e un browser Chrome/Edge moderno
con JavaScript attivo. Per la vista 3D serve WebGL2; le 12 sale restano
accessibili anche quando la vista 3D non e' disponibile.

Serve il repository Crypto Machine con la stessa struttura dell'implementazione
verificata: il server esistente deve offrire /plancia, /api/state e /vendor/three/.
Il pacchetto verifica server, engine, pagina esistente, Three.js locale r170
e OrbitControls prima di modificare la pagina. I grafici sono inclusi nella
pagina Crypto City: dashboard/charts.js e la sua route non sono necessari,
cosi' il pacchetto funziona anche con i server precedenti che ne sono privi.
Se mancano file o il checkout e' incompatibile, si ferma e mostra quali:
non sostituisce server o librerie e non scarica dipendenze.

COSA CAMBIA
L'installazione scrive solo dashboard/index.html. La pagina precedente viene
salvata in dashboard/.crypto-city-backups/index-<data>-<hash>.html.
Una seconda installazione identica non riscrive la pagina e non aggiunge backup.
Il percorso scelto viene ricordato solo dopo un'installazione riuscita, nel
file .crypto-city-local.json accanto all'installatore. Contiene soltanto il
percorso locale e la versione del formato, senza token o chiavi. Se il pacchetto
non e' scrivibile, l'installazione riesce comunque; scegli di nuovo la cartella
all'avvio. Una configurazione non valida viene ignorata. Per cambiare cartella,
elimina questo file oppure indica esplicitamente il percorso da terminale.
Per tornare alla pagina precedente, copia il backup scelto sopra
dashboard/index.html e ricarica /plancia.

Backend, engine, state, products, agenti, audit, regole di trading, integrazioni,
workflow GitHub e file locali esistenti non vengono sostituiti dall'installatore.
L'avvio usa dashboard/server.py esistente, sulla sola interfaccia locale,
con MM_AUTOSTART=false. I normali comportamenti del backend, incluso il
salvataggio dello stato all'avvio, restano quelli del progetto.

Il launcher verifica /healthz, la pagina con le 12 sale e /api/state prima di
aprire il browser. Se la porta 8877 e' occupata, controlla che serva la stessa
Crypto City; non termina processi e non avvia un secondo server.
I trade reali su Crypto.com continuano a richiedere la conferma del proprietario.

SE NON SI APRE
Leggi il messaggio nella finestra del launcher/server. Se viene segnalata una
porta occupata da un'altra applicazione, chiudi manualmente solo quella finestra
del server e riprova. Se i dati o i prezzi mancano, controlla gli errori del server:
le API e le connessioni esterne dipendono dalla tua configurazione esistente.
Non inserire chiavi API in questa chat o nei file del pacchetto.

USO DA TERMINALE (facoltativo)
python install_city.py "C:\percorso\crypto-machine"
python install_city.py --launch-only "C:\percorso\crypto-machine"
